"""G.O.O.D.A.S.S. package."""
